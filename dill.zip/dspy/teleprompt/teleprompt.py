class Teleprompter:
    def __init__(self):
        pass
