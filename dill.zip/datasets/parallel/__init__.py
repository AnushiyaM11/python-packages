from .parallel import ParallelBackendConfig, parallel_backend, parallel_map
