class BaseExtensionTests:
    pass
