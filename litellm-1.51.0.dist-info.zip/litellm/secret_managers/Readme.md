## Supported Secret Managers to read credentials from 

Example read OPENAI_API_KEY, AZURE_API_KEY from a secret manager