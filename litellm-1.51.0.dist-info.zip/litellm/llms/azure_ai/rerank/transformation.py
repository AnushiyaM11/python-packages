"""
Translate between Cohere's `/rerank` format and Azure AI's `/rerank` format. 
"""
